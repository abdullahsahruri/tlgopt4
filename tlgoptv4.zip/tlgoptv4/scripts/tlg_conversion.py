import sys

def replace_with_tlg(blif_file, custom_cell_file):
    output_blif_file = blif_file.replace('.blif', '_tlg.blif')
    thresholdable_functions = []  # Track thresholdable functions
    
    with open(blif_file, 'r') as blif, open(output_blif_file, 'w') as out_blif:
        print(f"Reading BLIF file: {blif_file}")
        
        current_fanin_count = 0
        for line in blif:
            # Skip metadata lines (e.g., comments and non-logic lines)
            if line.startswith("#") or line.startswith(".model") or line.startswith(".inputs") or line.startswith(".outputs") or line.startswith(".end"):
                out_blif.write(line)
                continue

            if '.names' in line:
                logic_function = line.strip().split()
                
                # Skip constants like $false, $true, $undef
                if logic_function[1] in ['$false', '$true', '$undef']:
                    out_blif.write(line)
                    continue
                
                # Count fanins (inputs) to this logic gate
                fanin_count = len(logic_function) - 1
                current_fanin_count = fanin_count  # Store this for cube validation
                
                # Only replace valid logic functions with TLG_GATE
                if is_thresholdable(logic_function):
                    tlg_line = f".names {' '.join(logic_function[1:])} TLG_GATE\n"
                    out_blif.write(tlg_line)
                    thresholdable_functions.append(logic_function[1:])
                    print(f"Replaced logic function with TLG_GATE: {logic_function[1:]}")
                else:
                    out_blif.write(line)
            elif len(line.strip()) > 0 and len(line.strip()) != current_fanin_count:
                # Skip cubes that don't match the fanin count
                print(f"Warning: Cube '{line.strip()}' has a different size ({len(line.strip())}) than the expected fanin count ({current_fanin_count}). Skipping.")
                continue
            else:
                out_blif.write(line)
                
        print(f"Written TLG-modified BLIF to: {output_blif_file}")

def is_thresholdable(function):
    # Check if the logic function is thresholdable (basic logic for now)
    return len(function) > 1 and len(function) <= 3  # 3-input logic gate at most

def main():
    if len(sys.argv) < 3:
        print("Usage: tlg_conversion.py <input_blif> <custom_cell_lib>")
        sys.exit(1)
    
    blif_file = sys.argv[1]
    custom_cell_file = sys.argv[2]
    
    # Call the replacement function to modify BLIF file with TLG gates
    replace_with_tlg(blif_file, custom_cell_file)

if __name__ == "__main__":
    main()

