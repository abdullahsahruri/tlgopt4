#!/bin/bash

# Directories that hold generated output files
LOGIC_CONES_DIR="../logic_cones"
OPTIMIZED_CONES_DIR="../optimized_cones"
STATS_DIR="../stats"
SCRIPTS_DIR="../scripts"

# Files or patterns to clean from the directories
TEMP_FILES=("*.blif" "*.txt" "*.log" "temp_*")

# Function to clean a directory
clean_directory() {
    local dir=$1
    echo "Cleaning directory: $dir"
    
    if [ -d "$dir" ]; then
        for pattern in "${TEMP_FILES[@]}"; do
            find "$dir" -name "$pattern" -exec rm -f {} \;
        done
        echo "Directory $dir cleaned."
    else
        echo "Directory $dir does not exist, skipping."
    fi
}

# Clean the directories
clean_directory "$LOGIC_CONES_DIR"
clean_directory "$OPTIMIZED_CONES_DIR"
clean_directory "$STATS_DIR"

# Clean temporary files in the scripts directory (temp files like temporary Yosys scripts)
clean_directory "$SCRIPTS_DIR"

echo "Cleanup complete."

