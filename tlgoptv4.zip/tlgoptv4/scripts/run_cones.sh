#!/bin/bash

# Check if the correct number of arguments is passed
if [ "$#" -ne 1 ]; then
    echo "Usage: ./run_cones.sh <benchmark_name>"
    exit 1
fi

# Assign the benchmark name and define paths to the Liberty files
benchmark_name=$1
design_file="../benchmarks/${benchmark_name}.v"
top_module=$benchmark_name
standard_lib_file="../liberty/standard.lib"  # Path to the standard cell Liberty file
tlg_lib_file="../liberty/tlg_cells.lib"      # Path to the TLG cell Liberty file
constr_file="../constraints/${benchmark_name}.constr"  # Path to the constraints file

# Check if the Verilog file exists
if [ ! -f "$design_file" ]; then
    echo "Error: Verilog file '$design_file' not found."
    exit 1
fi

# Check if the standard Liberty file exists
if [ ! -f "$standard_lib_file" ]; then
    echo "Error: Standard Liberty file '$standard_lib_file' not found."
    exit 1
fi

# Check if the custom TLG Liberty file exists
if [ ! -f "$tlg_lib_file" ]; then
    echo "Error: Custom TLG Liberty file '$tlg_lib_file' not found."
    exit 1
fi

# Create directories for storing logic cones, optimized files, and stats
mkdir -p ../logic_cones
mkdir -p ../optimized_cones
mkdir -p ../stats

# Step 1: Run Yosys to generate the BLIF file for the logic cones using the standard Liberty file
cat <<EOT > temp_yosys_script.ys
# Read the Verilog file
read_verilog $design_file

# Perform synthesis with the top module
synth -top $top_module

# Flatten the design to remove hierarchy
flatten

# Map the design using the standard Liberty file for initial synthesis
dfflibmap -liberty $standard_lib_file

# Write the design to a BLIF file for ABC to process
write_blif ../logic_cones/${benchmark_name}.blif
EOT

yosys -s temp_yosys_script.ys

# Check if the BLIF file was created
if [ ! -f "../logic_cones/${benchmark_name}.blif" ]; then
    echo "Error: Yosys failed to generate the BLIF file."
    exit 1
fi

# Step 2: Run TLF detection on the generated BLIF file
python3 ../scripts/tlg_detection.py ../logic_cones/${benchmark_name}.blif ../custom_cells/tlg_cells.v

# Step 3: Convert logic cones with TLGs
python3 ../scripts/tlg_conversion.py ../logic_cones/${benchmark_name}.blif ../custom_cells/tlg_cells.v

# Step 4: Optimize the TLG-substituted BLIF using ABC without Liberty mapping (Yosys has already handled Liberty mapping)
abc -c "read_blif ../logic_cones/${benchmark_name}_tlg.blif; strash; dc2; write_blif ../optimized_cones/optimized_${benchmark_name}_tlg.blif"

# Check if ABC successfully generated the optimized BLIF file
if [ ! -f "../optimized_cones/optimized_${benchmark_name}_tlg.blif" ]; then
    echo "Error: ABC failed to optimize the design."
    exit 1
fi

# Step 5: Save statistics after ABC optimization
yosys -p "read_blif ../optimized_cones/optimized_${benchmark_name}_tlg.blif; stat -liberty $tlg_lib_file" > ../stats/stat_after_${benchmark_name}_tlg.txt
yosys -p "read_blif ../optimized_cones/optimized_${benchmark_name}_tlg.blif; stat -liberty $standard_lib_file" > ../stats/stat_after_${benchmark_name}_std.txt

# Clean up temporary Yosys script
rm temp_yosys_script.ys

