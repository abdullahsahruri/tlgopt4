import sys

def parse_blif(file):
    thresholdable_cones = []
    with open(file, 'r') as blif:
        for line in blif:
            if '.names' in line:
                logic_function = line.strip().split()
                if is_thresholdable(logic_function):
                    thresholdable_cones.append(logic_function[0])  # Capture the logic function
    return thresholdable_cones

def is_thresholdable(function):
    # Implement your threshold detection logic based on the paper's algorithm
    # For now, let's assume any 3-input function is thresholdable
    return len(function) <= 3

def write_tlf_output(thresholdable_cones, output_file):
    with open(output_file, 'w') as out:
        for cone in thresholdable_cones:
            out.write(f"{cone} is a threshold logic function.\n")

def main():
    blif_file = sys.argv[1]
    output_file = f"{blif_file}_tlf.txt"
    thresholdable_cones = parse_blif(blif_file)
    write_tlf_output(thresholdable_cones, output_file)

if __name__ == "__main__":
    main()

